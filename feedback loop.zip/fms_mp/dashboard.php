<!-- handle 'dashboard-module' ['users'] -->
<?php

// Start session
session_start();

// Include utilities
require_once('includes/DB.php');
$DB = new DB();
$connected = $DB->newConnection();

// Authorization check
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'student') {
    header("Location: index.php");
    exit;
}

// Fetch faculty members
$faculty_members = $DB->fetchAllFaculties();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo $_SESSION['username']; ?></title>
    <link rel="stylesheet" href="dashboard.css"> <!-- Link to your new dashboard.css -->
</head>

<body>
    <div class="dashboard-container">
        <header class="header">
            <h1>Student Dashboard</h1>
            <nav class="nav">
                <a href="includes/logout.php">Logout</a>
            </nav>
        </header>

        <main class="main-content">
            <section class="welcome-section">
                <h3>Welcome, <?php echo $_SESSION['username']; ?></h3>
            </section>

            <section class="submit-review">
                <h4>Submit a Faculty Review</h4>
                <form action="./student/submit_review.php" method="POST">
                    <div class="form-group">
                        <label for="faculty_id">Select Faculty to Review</label>
                        <select name="faculty_id" required>
                            <?php foreach ($faculty_members as $faculty): ?>
                                <option value="<?php echo $faculty['id']; ?>"><?php echo $faculty['name']; ?> - <?php echo $faculty['department']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="rating">Rating</label>
                        <select name="rating" required>
                            <option value="good">Good</option>
                            <option value="better">Better</option>
                            <option value="best">Best</option>
                            <option value="decent">Decent</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="comment">Comment</label>
                        <textarea name="comment" placeholder="Leave your review here!" required></textarea>
                    </div>

                    <button type="submit">Submit Review</button>
                </form>
            </section>

            <section class="all -reviews">
                <h4>Your Submitted Reviews</h4>
                <?php
                $reviews = $DB->fetchUserReviews($_SESSION['user_id']);
                if (count($reviews) > 0) {
                    foreach ($reviews as $review) {
                        echo "<div class='review-card'>";
                        echo "<h5>" . htmlspecialchars($review['faculty_name']) . "</h5>";
                        echo "<p>Rating: " . ucfirst(htmlspecialchars($review['rating'])) . "</p>";
                        echo "<p>Comment: " . htmlspecialchars($review['comment']) . "</p>";
                        echo "<p class='status'>Status: " . ucfirst(htmlspecialchars($review['status'])) . "</p>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>You haven't submitted any reviews yet.</p>";
                }
                ?>
            </section>
        </main>
    </div>
</body>

</html>