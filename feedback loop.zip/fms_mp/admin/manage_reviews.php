<!-- handle review-management -->
<?php
//. new session
session_start();

//. grab utilties...
require_once('../includes/DB.php');
$DB = new DB();
$connected = $DB->newConnection();

//. check authorization!
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {

    //. shift to 'login-module' instantly
    header("Location: index.php");
    exit;
}

// grab all Pending Reviews
$pending_reviews = $DB->fetchAllPendingReviews();
?>

<!-- structure for 'review-management' ['admin-module'] -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
</head>

<body>
    <h2>Admin Dashboard</h2>
    <h3>Welcome, <?php echo $_SESSION['username']; ?></h3>

    <div>
        <h4>Pending Reviews</h4>
        <?php foreach ($pending_reviews as $review): ?>
            <div>
                <p><strong>Faculty:</strong> <?php echo $review['faculty_name']; ?></p>
                <p><strong>Student:</strong> <?php echo $review['student_name']; ?></p>
                <p><strong>Rating:</strong> <?php echo $review['rating']; ?></p>
                <p><strong>Comment:</strong> <?php echo $review['comment']; ?></p>
                <form action="review_action.php" method="POST">
                    <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">
                    <button type="submit" name="action" value="approve">Approve</button>
                    <button type="submit" name="action" value="reject">Reject</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</body>

</html>