<!-- handle faculty-delete from 'dashboard-module of admin' -->
<?php
//. new session
session_start();

//. grab utilties...
require_once('../includes/DB.php');
$DB = new DB();
$connected = $DB->newConnection();

//. check authorization!
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {

    //. shift to 'login-module' instantly
    header("Location: index.php");
    exit;
}

// grab faculty data by ID
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    //. invoke () -> delete faculty
    $DB->deleteFaculty($id);

    //. shift to dashboard
    header("Location: dashboard.php");
}
?>