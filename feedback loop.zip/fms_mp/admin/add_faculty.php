<!-- handle faculty-add from 'dashboard-module of admin' -->
<?php
//. new session
session_start();

//. grab utilties...
require_once('../includes/DB.php');
$DB = new DB();
$connected = $DB->newConnection();

//. check authorization!
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {

    //. shift to 'login-module' instantly
    header("Location: index.php");
    exit;
}


//. handle new faculty
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    //. user-input
    $name = $_POST['name'];
    $department = $_POST['department'];
    $designation = $_POST['designation'];

    // file-input
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {

        //. final-location
        $target_dir = "../profiles/";
        $profile_pic = basename($_FILES["profile_pic"]["name"]);
        $target_file = $target_dir . $profile_pic;

        // Check file type
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        //. sanitize [validate] picture sizes!
        if (in_array($imageFileType, ["jpg", "png", "jpeg", "gif", "avif"])) {
            move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file);
        } else {
            echo "Only JPG, JPEG, PNG & GIF files are allowed.";
            exit;
        }
    } else {

        // default profile picture if no file is uploaded
        $profile_pic = 'default.png';
    }


    //. invoke () -> add new faculty!
    $DB->newFaculty($name, $department, $designation, $profile_pic);

    //. shift to 'admin-dashboard-module'...
    header("Location: dashboard.php");
}
