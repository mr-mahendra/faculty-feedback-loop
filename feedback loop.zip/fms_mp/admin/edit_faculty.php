<!-- handle faculty-edit from 'dashboard-module of admin' -->
<?php
//. new session
session_start();

//. grab utilties...
require_once('../includes/DB.php');
$DB = new DB();
$connected = $DB->newConnection();

//. check authorization!
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {

    //. shift to 'login-module' instantly
    header("Location: index.php");
    exit;
}

// grab faculty data by ID
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    //. grab faculty
    $faculty = $DB->fetchFaculty($id);
}

// error-handlers
$nameErr = null;
$departmentErr = null;
$designationErr = null;
$isValid = true;

// handle update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    //. user-data
    $name = $_POST['name'];
    $department = $_POST['department'];
    $designation = $_POST['designation'];
    $profile_pic = $faculty['profile_pic'];

    // Update profile picture if a new file is uploaded
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $target_dir = "../uploads/";
        $profile_pic = basename($_FILES["profile_pic"]["name"]);
        $target_file = $target_dir . $profile_pic;
        move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file);
    }

    //. sanitize [validate] inputs before any further processes...
    if (empty($name)) {
        //. throw err
        $nameErr = "name is required for update!";
        $isValid = false;
    }

    if (empty($department)) {
        //. throw err
        $departmentErr = "department is required for update!";
        $isValid = false;
    }

    if (empty($designation)) {
        //. throw err
        $designationErr = "designation is required for update!";
        $isValid = false;
    }

    //. Okay! then proceed further...
    if ($isValid) {
        //. invoke () -> modify faculty
        $DB->editFaculty($name, $department, $designation, $profile_pic, $id);

        //. shift to dashboard
        header("Location: dashboard.php");
    }
}
?>

<!-- structure for dashboard-module (admin) [edit-faculty] -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php
        echo isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin';
        ?>
    </title>
</head>

<body>
    <!-- edit-faculty -->
    <section class="edit-faculty">
        <center>
            <h3>Edit</h3>
            <div>
                <h4><?php echo $_SESSION['username']; ?></h4>
                <img src="../profiles/<?php echo !empty($faculty['profile_pic']) ? $faculty['profile_pic'] : 'default.png'; ?>" alt="Profile Pic" width="100" style="border-radius: 50px;" />
                <br /> <br />

                <form method="POST" enctype="multipart/form-data">
                    <input type="text" name="name" value="<?php echo $faculty['name']; ?>" autocomplete="off" />
                    <!-- Error-toast -->
                    <span style="color: crimson;"><?php echo $nameErr; ?></span>
                    <br /> <br />

                    <input type="text" name="department" value="<?php echo $faculty['department']; ?>" autocomplete="off" />
                    <!-- Error-toast -->
                    <span style="color: crimson;"><?php echo $departmentErr; ?></span>
                    <br /> <br />

                    <input type="text" name="designation" value="<?php echo $faculty['designation']; ?>" autocomplete="off" />
                    <!-- Error-toast -->
                    <span style="color: crimson;"><?php echo $designationErr; ?></span>
                    <br /> <br />

                    <label>Profile Picture:</label>
                    <input type="file" name="profile_pic" />
                    <br /> <br />
                    <button type="submit">Update Faculty</button>
                </form>
            </div>
        </center>
    </section>
</body>

</html>