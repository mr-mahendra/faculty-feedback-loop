<!-- handle 'dashboard-module' ['admin'] -->
<?php
session_start();
require_once('../includes/DB.php');
$DB = new DB();
$connected = $DB->newConnection();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

$faculty_members = $DB->fetchAllFaculties();
$departments = ['MCA', 'MSC IT', 'BCA', 'BSC IT']; // Example departments
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin'; ?>
    </title>
    <link rel="stylesheet" href="dashboard.css"> <!-- Link to your new dashboard.css -->
</head>

<body>
    <div class="dashboard-container">
        <header class="header">
            <h1>Admin Dashboard</h1>
            <nav class="nav">
                <a href="../includes/logout.php">Logout</a>
                <a href="manage_reviews.php">Review Management</a>
            </nav>
        </header>

        <main class="main-content">
            <section class="welcome-section">
                <h3>Welcome, <?php echo $_SESSION['username']; ?></h3>
            </section>

            <section class="add-faculty">
                <h4>Add New Faculty</h4>
                <form action="add_faculty.php" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" required placeholder="Name" autocomplete="off" />
                    </div>
                    <div class="form-group">
                        <label for="department">Department</label>
                        <select name="department" required>
                            <option value="" disabled selected>Select Department</option>
                            <?php foreach ($departments as $department): ?>
                                <option value="<?php echo $department; ?>"><?php echo $department; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="designation">Designation</label>
                        <input type="text" name="designation" required placeholder="Designation" autocomplete="off" />
                    </div>
                    <div class="form-group">
                        <label for="profile_pic">Profile Picture:</label>
                        <input type="file" name="profile_pic">
                    </div>
                    <button type="submit">Add Faculty</button>
                </form>
            </section>

            <section class="faculty-list">
                <h4>Faculty List</h4>
                <div class="faculty-cards">
                    <?php foreach ($faculty_members as $faculty): ?>
                        <div class="faculty-card">
                            <img src="../profiles/<?php echo !empty($faculty['profile_pic']) ? $faculty['profile_pic'] : 'default.png'; ?>" alt="Profile Pic" class="profile-pic" />
                            <div class="faculty-info">
                                <h5><?php echo $faculty['name']; ?></h5>
                                <p><strong>Department:</strong> <?php echo $faculty['department']; ?></p>
                                <p><strong>Designation:</strong> <?php echo $faculty['designation']; ?></p>
                            </div>
                            <div class="actions">
                                <a href="edit_faculty.php?id=<?php echo $faculty['id']; ?>">Edit</a>
                                <a href="delete_faculty.php?id=<?php echo $faculty['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </main>
    </div>
</body>

</html>