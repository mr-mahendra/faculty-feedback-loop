<!-- handle review-action   -->
<?php
//. new session
session_start();

//. grab utilties...
require_once('../includes/DB.php');
$DB = new DB();
$connected = $DB->newConnection();

//. check authorization!
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {

    //. shift to 'login-module' instantly
    header("Location: index.php");
    exit;
}

// handle review-actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    //. grab user-input
    $review_id = $_POST['review_id'];
    $action = $_POST['action'];

    // handle status as per choice?
    //. before any modifications.... 
    if ($action == 'approve') {
        $status = 'approved';
    } elseif ($action == 'reject') {
        $status = 'rejected';
    }

    //. invoke () -> update `status`! 
    $DB->editStatus($status, $review_id);

    // shift to `admin-dashboard`
    header("Location: dashboard.php");
}
?>