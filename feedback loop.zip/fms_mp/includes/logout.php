<?php

// start session
session_start();

//. unset the existing session!
session_unset();

//. terminate all sessions!
session_destroy();

// shift to `index.php` [login-module]
header('Location: ../index.php');
