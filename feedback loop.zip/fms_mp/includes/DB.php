<!-- TO HANDLE DATA_SOURCE INTERACTION -->
<?php

// class DB
class DB
{

    //. credentials**
    private $host = "localhost";
    private $dbname = "fms";
    private $user = "root";
    private $password = "";


    //. intialize resource...
    private $connection = null;


    //. () -> build connection to Data-source
    public function newConnection()
    {

        //. error-prone area
        try {

            //. check resource?
            if ($this->connection == null) {

                //. initiate new connection
                $this->connection = new PDO("mysql:host={$this->host};dbname={$this->dbname}", $this->user, $this->password);

                //. set error-mode to exception!
                $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
        }

        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION : " . $pdoEx->getMessage());
        }


        //. return connection
        return $this->connection;
    }


    //. () -> new user ['register-module']
    public function newUser($username, $email, $password, $role)
    {

        //. error-prone area
        try {

            //. new command!
            $addUser = "INSERT INTO users (username, email, password, role) VALUES (:username, :email, :password, :role)";

            //. prepared-statement to handle above command!
            $pStmt = $this->connection->prepare($addUser);

            //. bind every parameter or value before executing!
            $pStmt->bindParam(':username', $username);
            $pStmt->bindParam(':email', $email);
            $pStmt->bindParam(':password', $password);
            $pStmt->bindParam(':role', $role);

            //. execute the command via prepared-statement
            //. && check?
            if ($pStmt->execute()) {
                //. simple toast
                echo $username . " JUST JOINED!";
            } else {
                die("OOP'S! USER COULDN'T BE ADDED...");
            }
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! USER CANNOT BE REGISTERED! " . $pdoEx->getMessage());
        }
    }


    //. () -> isLegit ['login-module']
    public function isLegit($username)
    {

        //. error-prone area
        try {

            //. new command!
            $fetchLegitUser = "SELECT * FROM users WHERE username = :username";

            //. prepared-statement to handle above query!
            $pStmt = $this->connection->prepare($fetchLegitUser);

            //. bind every parameter or value before executing!
            $pStmt->bindParam(':username', $username);

            //. execute the query via prepared-statement
            $pStmt->execute();

            //. grab user as assoc-array!
            $fetchedUser = $pStmt->fetch(PDO::FETCH_ASSOC);
            return $fetchedUser;
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! NO USER FOUND! " . $pdoEx->getMessage());
        }
    }


    //. () -> all faculties ['admin-module']
    public function fetchAllFaculties()
    {
        //. error-prone area
        try {

            //. new command!
            $allFaculties = "SELECT * FROM faculty";

            //. prepared-statement to handle above query!
            $pStmt = $this->connection->prepare($allFaculties);;

            //. execute the query via prepared-statement
            $pStmt->execute();

            //. grab user as assoc-array!
            $fetchedFaculties = $pStmt->fetchAll(PDO::FETCH_ASSOC);
            return $fetchedFaculties;
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! NO DATA FOUND " . $pdoEx->getMessage());
        }
    }

    //. () -> new faculty ['admin-module']
    public function newFaculty($name, $department, $designation, $profile_pic)
    {

        //. error-prone area
        try {

            //. new command!
            $addUser = "INSERT INTO faculty (name, department, designation, profile_pic) VALUES (:name, :department, :designation, :profile_pic)";

            //. prepared-statement to handle above command!
            $pStmt = $this->connection->prepare($addUser);

            //. bind every parameter or value before executing!
            $pStmt->bindParam(':name', $name);
            $pStmt->bindParam(':department', $department);
            $pStmt->bindParam(':designation', $designation);
            $pStmt->bindParam(':profile_pic', $profile_pic);

            //. execute the command via prepared-statement
            //. && check?
            if ($pStmt->execute()) {
                //. simple toast
                echo " FACULTY " . $name . " JUST JOINED!";
            } else {
                die("OOP'S! USER COULDN'T BE ADDED...");
            }
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! USER CANNOT BE REGISTERED! " . $pdoEx->getMessage());
        }
    }

    //. () -> fetch faculty ['admin-module']
    public function fetchFaculty($id)
    {

        //. error-prone area
        try {

            //. new command!
            $fetchLegitUser = "SELECT * FROM faculty WHERE id = :id";

            //. prepared-statement to handle above query!
            $pStmt = $this->connection->prepare($fetchLegitUser);

            //. bind every parameter or value before executing!
            $pStmt->bindParam(':id', $id);

            //. execute the query via prepared-statement
            $pStmt->execute();

            //. grab faculty as assoc-array!
            $fetchedFaculty = $pStmt->fetch(PDO::FETCH_ASSOC);
            return $fetchedFaculty;
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! NO USER FOUND! " . $pdoEx->getMessage());
        }
    }

    //. () -> update faculty ['admin-module']
    public function editFaculty($name, $department, $designation, $profile_pic, $id)
    {

        //. error-prone area
        try {

            //. new command!
            $editUser = "UPDATE faculty SET name = :name, department = :department, designation = :designation, profile_pic = :profile_pic WHERE id = :id";

            //. prepared-statement to handle above command!
            $pStmt = $this->connection->prepare($editUser);

            //. bind every parameter or value before executing!
            $pStmt->bindParam(':name', $name);
            $pStmt->bindParam(':department', $department);
            $pStmt->bindParam(':designation', $designation);
            $pStmt->bindParam(':profile_pic', $profile_pic);
            $pStmt->bindParam(':id', $id);

            //. execute the command via prepared-statement
            //. && check?
            if ($pStmt->execute()) {
                //. simple toast
                echo " FACULTY " . $name . " JUST MODIFIED!";
            } else {
                die("OOP'S! FACULTY COULDN'T BE MODIFIED...");
            }
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! FACULTY COULDN'T BE MODIFIED! " . $pdoEx->getMessage());
        }
    }

    //. () -> delete faculty ['admin-module']
    public function deleteFaculty($id)
    {

        //. error-prone area
        try {

            //. new command!
            $deleteUser = "DELETE FROM faculty WHERE id = :id";

            //. prepared-statement to handle above command!
            $pStmt = $this->connection->prepare($deleteUser);

            //. bind every parameter or value before executing!
            $pStmt->bindParam(':id', $id);

            //. execute the command via prepared-statement
            //. && check?
            if ($pStmt->execute()) {
                //. simple toast
                echo " FACULTY REMOVED";
            } else {
                die("OOP'S! FACULTY COULDN'T BE REMOVED...");
            }
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! FACULTY COULDN'T BE MODIFIED! " . $pdoEx->getMessage());
        }
    }


    //. () -> fetch reviews by user (student) ['user-module']
    public function fetchUserReviews($id)
    {

        //. error-prone area
        try {

            //. new query!
            $fetchReviews = "SELECT r.*, f.name AS faculty_name FROM reviews r JOIN faculty f ON r.faculty_id = f.id WHERE r.student_id = :id";

            //. prepared-statement to handle above query!
            $pStmt = $this->connection->prepare($fetchReviews);

            //. bind every parameter or value before executing!
            $pStmt->bindParam(':id', $id);

            //. execute the query via prepared-statement
            $pStmt->execute();

            //. grab faculty as assoc-array!
            $fetchedFacultyReviews = $pStmt->fetchAll(PDO::FETCH_ASSOC);
            return $fetchedFacultyReviews;
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! NO USER FOUND! " . $pdoEx->getMessage());
        }
    }

    //. () -> new review by user (student) ['user-module']
    public function newReview($faculty_id, $student_id, $rating, $comment)
    {

        //. error-prone area
        try {

            //. new command!
            $addNewReview = "INSERT INTO reviews (faculty_id, student_id, rating, comment) VALUES (:faculty_id, :student_id, :rating, :comment)";

            //. prepared-statement to handle above command!
            $pStmt = $this->connection->prepare($addNewReview);

            //. bind every parameter or value before executing!
            $pStmt->bindParam(':faculty_id', $faculty_id);
            $pStmt->bindParam(':student_id', $student_id);
            $pStmt->bindParam(':rating', $rating);
            $pStmt->bindParam(':comment', $comment);

            //. execute the command via prepared-statement
            //. && check?
            if ($pStmt->execute()) {
                //. simple toast
                echo "Review submitted successfully!";

                //. shift to 'user-dashboard'
                header("Location: ../dashboard.php");
            } else {
                echo "Failed to submit review. Please try again.";
            }
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! USER CANNOT BE REGISTERED! " . $pdoEx->getMessage());
        }
    }

    //. () -> fetch all pending-reviews ['admin-module']
    public function fetchAllPendingReviews()
    {
        //. error-prone area
        try {

            //. new command!
            $allPendingReviews = "SELECT reviews.id, reviews.rating, reviews.comment, reviews.status, faculty.name AS faculty_name, users.username AS student_name 
                       FROM reviews 
                       JOIN faculty ON reviews.faculty_id = faculty.id 
                       JOIN users ON reviews.student_id = users.id 
                       WHERE reviews.status = 'pending'";

            //. prepared-statement to handle above query!
            $pStmt = $this->connection->prepare($allPendingReviews);;

            //. execute the query via prepared-statement
            $pStmt->execute();

            //. grab user as assoc-array!
            $fetchedPendingReviews = $pStmt->fetchAll(PDO::FETCH_ASSOC);
            return $fetchedPendingReviews;
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! NO DATA FOUND " . $pdoEx->getMessage());
        }
    }

    //. () -> update status ['admin-module']
    public function editStatus($status, $review_id)
    {

        //. error-prone area
        try {

            //. new command!
            $editCurrentStatus = "UPDATE reviews SET status = :status WHERE id = :id";

            //. prepared-statement to handle above command!
            $pStmt = $this->connection->prepare($editCurrentStatus);

            //. bind every parameter or value before executing!
            $pStmt->bindParam(':status', $status);
            $pStmt->bindParam(':id', $review_id);

            //. execute the command via prepared-statement
            //. && check?
            if ($pStmt->execute()) {
                //. simple toast
                echo " REVIEW STATUS WAS JUST MODIFIED! " . $status . "";
            } else {
                die("OOP'S! STATUS COULDN'T BE MODIFIED...");
            }
        }


        //. handle run-time events
        catch (PDOException $pdoEx) {

            //. handle run-time error and terminate execution!
            die("EXCEPTION -> OOPS's! REVIEW STATUS COULDN'T BE MODIFIED! " . $pdoEx->getMessage());
        }
    }
}
?>