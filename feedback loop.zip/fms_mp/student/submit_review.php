<!-- handle review-submission ['user-module'] -->
<?php
//. new session
session_start();

//. grab utilties...
require_once('../includes/DB.php');
$DB = new DB();
$connected = $DB->newConnection();

//. check authorization!
if (!isset($_SESSION['username']) || !isset($_SESSION['user_id'])  || $_SESSION['role'] != 'student') {

    //. shift to 'login-module' instantly
    header("Location: index.php");
    exit;
}

// handle review-submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    //. grab details
    $faculty_id = $_POST['faculty_id'];
    $student_id = $_SESSION['user_id'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];

    // invoke () -> submit a review...
    $DB->newReview($faculty_id, $student_id, $rating, $comment);
}
?>